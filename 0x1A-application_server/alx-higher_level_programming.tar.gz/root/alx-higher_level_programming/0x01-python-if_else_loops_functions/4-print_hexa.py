#!/usr/bin/python3
for number in range(0, 99):
    print('{} = 0x{:x}'.format(number, number))
