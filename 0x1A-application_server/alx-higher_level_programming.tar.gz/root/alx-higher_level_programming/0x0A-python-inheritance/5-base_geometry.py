#!/usr/bin/python3
"""Empty class BaseGeometry."""


class BaseGeometry:
    """Represent base geometry."""
    pass
