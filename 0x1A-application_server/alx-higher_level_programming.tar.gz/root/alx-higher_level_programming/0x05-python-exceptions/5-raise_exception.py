#!/usr/bin/python3
def raise_exception():
    raise TypeError
