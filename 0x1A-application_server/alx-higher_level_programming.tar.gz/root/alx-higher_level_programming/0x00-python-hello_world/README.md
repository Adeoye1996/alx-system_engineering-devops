This a README.md for 0x00-python-hello_world
the directory contains all the task for the 0x00-python-hello_world
