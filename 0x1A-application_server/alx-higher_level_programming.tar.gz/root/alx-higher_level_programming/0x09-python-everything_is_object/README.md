This is a readme file containing 0x09-python-everything_is_object
Tasks
0. Who am I?
mandatory
What function would you use to get the type of an object?

Write the name of the function in the file, without ().
1. Where are you?
mandatory
How do you get the variable identifier (which is the memory address in the CPython implementation)?

Write the name of the function in the file, without ().
2. Right count
mandatory
In the following code, do a and b point to the same object? Answer with Yes or No.
3. Right count =
mandatory
In the following code, do a and b point to the same object? Answer with Yes or No.
