#!/usr/bin/python3
def copy_list(my_list):
    return my_list.copy()
