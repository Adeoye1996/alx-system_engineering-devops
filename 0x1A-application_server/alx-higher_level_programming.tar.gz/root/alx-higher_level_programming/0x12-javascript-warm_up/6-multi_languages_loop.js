#!/usr/bin/node

const lines = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
let i = 0;

while (i < lines.length) {
  console.log(lines[i]);
  i++;
}
