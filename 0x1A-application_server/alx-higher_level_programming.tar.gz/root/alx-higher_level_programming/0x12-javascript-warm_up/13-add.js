#!/usr/bin/node
exports.add = function (x, y) {
  return (x + y);
};
