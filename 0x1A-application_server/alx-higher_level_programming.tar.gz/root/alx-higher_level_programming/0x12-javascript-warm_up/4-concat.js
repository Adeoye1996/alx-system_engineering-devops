#!/usr/bin/node

const [,, arg1, arg2] = process.argv;

console.log(arg1 + ' is ' + arg2);
