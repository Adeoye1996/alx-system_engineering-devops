This is a javaScript warmup
Requirements
General

    Allowed editors: vi, vim, emacs
    All your files will be interpreted on Ubuntu 20.04 LTS using node (version 14.x)
    All your files should end with a new line
    The first line of all your files should be exactly #!/usr/bin/node
    A README.md file, at the root of the folder of the project, is mandatory
    Your code should be semistandard compliant (version 16.x.x). Rules of Standard + semicolons on top. Also as reference: AirBnB style
    All your files must be executable
    The length of your files will be tested using wc
Tasks
0. First constant, first print
mandatory

Write a script that prints “JavaScript is amazing”:

    You must create a constant variable called myVar with the value “JavaScript is amazing”
    You must use console.log(...) to print all output
    You are not allowed to use var

1. 3 languages
mandatory

Write a script that prints 3 lines:

    The first line: “C is fun”
    The second line: “Python is cool”
    The third line: “JavaScript is amazing”
    You must use console.log(...) to print all output
    You are not allowed to use var

